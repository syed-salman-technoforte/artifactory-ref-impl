import type { StoryObj } from "@storybook/web-components";
import { init } from "../lib";
import { ISignInWithEsignetProps } from "../lib/SignInWithEsignet/ISignInWithEsignetProps";
declare const SignInWithEsignetMeta: {
    title: string;
    tags: string[];
    render: (args: ISignInWithEsignetProps) => import("lit-html").TemplateResult<1>;
    argTypes: {
        oidcConfig: {
            control: string;
        };
        buttonConfig: {
            control: string;
        };
    };
};
export default SignInWithEsignetMeta;
type Story = StoryObj<typeof init>;
export declare const SignInWithEsignetStory: Story;
